# Portfolio — Thery NDZOBE

Version éditoriale et responsive, conçue pour GitHub Pages. La palette est blanc cassé / graphite / olive, sans bleu.

## Mise en ligne

1. Décompressez l'archive.
2. Dans le dépôt GitHub Pages existant `thery-NDZOBE-portfolio`, envoyez à la **racine** : `index.html`, `parcours.html`, `projets.html`, `contact.html`, `style.css`, `site.js` et le dossier `assets/`.
3. Conservez (ou ajoutez) à cette même racine votre photographie `photoportfolio.png` (ou `photoportfolio.jpg`) et votre CV actualisé **`cv.pdf`**. S'ils ne sont pas disponibles, le site affiche un monogramme pour la photo ; le bouton du CV ne fonctionnera pas tant que le PDF n'est pas ajouté.
4. Vérifiez les fichiers dans l'onglet **Code**, puis dans **Settings → Pages** assurez-vous que la publication se fait depuis la branche `main`, dossier `/ (root)`.
5. Ouvrez votre lien GitHub Pages une fois les changements publiés.

## Fonctionnement

- HTML/CSS/JavaScript natifs, sans framework ni installation.
- Menu mobile, filtres de projets, accordéons détaillés, balises accessibles, optimisation responsive.
- Liens relatifs adaptés au chemin d'un dépôt GitHub Pages de projet.
- LinkedIn : https://www.linkedin.com/in/thery-ndzobe-ba0485364/
- Email : theryprofessionel@gmail.com
- Aucune donnée de collecte ni formulaire côté serveur.
- Les six SVG sont des illustrations **conceptuelles originales** et non des schémas réels d'entreprise.

## Important

Avant de publier, relisez les descriptions professionnelles et assurez-vous que vous avez le droit de diffuser toute image réelle d'entreprise que vous décidez d'ajouter. Le dossier ne comprend ni vos fichiers de travail confidentiels, ni vos photos ou CV non fournis.

## Fichiers

- `index.html` : accueil
- `parcours.html` : formation, expérience et compétences
- `projets.html` : six projets avec filtres et détails
- `contact.html` : contact professionnel
- `style.css` : design
- `site.js` : menu mobile, filtres, photo de secours
- `assets/` : icône et illustrations vectorielles
