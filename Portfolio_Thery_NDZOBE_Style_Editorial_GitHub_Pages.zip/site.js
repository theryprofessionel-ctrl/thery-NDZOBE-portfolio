(() => {
 const menuButton=document.querySelector('#menu-button');
 const mobileNav=document.querySelector('#mobile-nav');
 const setMenu=(open)=>{if(!menuButton||!mobileNav)return;menuButton.setAttribute('aria-expanded',String(open));mobileNav.hidden=!open;menuButton.setAttribute('aria-label',open?'Fermer le menu':'Ouvrir le menu');menuButton.innerHTML=open?'<svg class="icon" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><path d="M5 5l14 14M19 5 5 19"/></svg><span>Fermer</span>':'<svg class="icon" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><path d="M4 7h16M4 12h16M4 17h16"/></svg><span>Menu</span>';};
 menuButton?.addEventListener('click',()=>setMenu(menuButton.getAttribute('aria-expanded')!=='true'));
 mobileNav?.querySelectorAll('a').forEach(a=>a.addEventListener('click',()=>setMenu(false)));
 document.addEventListener('keydown',e=>{if(e.key==='Escape')setMenu(false)});
 document.addEventListener('click',e=>{if(mobileNav&&!mobileNav.hidden&&!e.composedPath().some(node=>node && node.id==='site-header'))setMenu(false)});
 window.matchMedia('(min-width: 861px)').addEventListener('change',e=>{if(e.matches)setMenu(false)});
 const filters=[...document.querySelectorAll('.filter-btn')];const cards=[...document.querySelectorAll('.project-item')];const counter=document.querySelector('#projects-count');
 filters.forEach(btn=>btn.addEventListener('click',()=>{const f=btn.dataset.filter;filters.forEach(b=>{const on=b===btn;b.classList.toggle('is-active',on);b.setAttribute('aria-pressed',String(on))});let count=0;cards.forEach(c=>{const show=f==='tous'||c.dataset.category===f;c.hidden=!show;if(show)count++});if(counter)counter.textContent=count+' projet'+(count===1?'':'s')+' affiché'+(count===1?'':'s')}));
 function focusHash(){const hash=decodeURIComponent(location.hash.slice(1));if(!hash)return;const el=document.getElementById(hash);if(el?.classList.contains('project-item')){const parentFilter=el.dataset.category;const activeFilter=document.querySelector('.filter-btn.is-active');if(activeFilter && activeFilter.dataset.filter!== 'tous' && activeFilter.dataset.filter!==parentFilter){document.querySelector('.filter-btn[data-filter="tous"]')?.click()}el.querySelector('details')?.setAttribute('open','');}}
 window.addEventListener('hashchange',focusHash);focusHash();
})();